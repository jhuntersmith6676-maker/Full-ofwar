# Build Frontline Command from your Android phone (cloud build)

This project is prepared for Unity Build Automation. You do not need a Windows PC, but you do need to connect your own Unity ID and GitHub account.

## 1. Put the project in GitHub
1. Open https://github.com in Chrome and sign in (create a free account if needed).
2. Create a new **private** repository named `FrontlineCommand`.
3. Extract this ZIP on a device that can upload files. Upload the *contents* of the project folder (the `Assets`, `Packages`, and `ProjectSettings` folders plus README files) to the repository root. Do not upload the outer ZIP as the only repository file.
4. Confirm `Assets/Scenes/Battlefield.unity`, `Assets/Scripts/FrontlineCommandV2.cs`, `Packages/manifest.json`, and `ProjectSettings/ProjectVersion.txt` appear in the repository.

## 2. Connect Unity Build Automation
1. Open https://cloud.unity.com and sign in with your Unity ID.
2. Open **DevOps → Build Automation**.
3. In Settings → Source control, connect GitHub and authorize read access to the `FrontlineCommand` repository.
4. Create a build configuration. Choose Android, branch `main`, and Unity version `2022.3.62f1` (or a supported 2022.3 LTS version).
5. Select an Android builder and save the configuration.
6. In Build History, press **Build**.

Unity's cloud build service uses the repository to compile your project for Android. It will show build logs and provide an APK download when successful.

## 3. Install the APK
1. Download the APK from the completed build in Unity Dashboard on your Android phone.
2. Open the downloaded APK.
3. If Android asks, allow Chrome or your file manager to install unknown apps for this installation.
4. Install and launch Frontline Command.

## Important
- Unity Build Automation is a separate cloud service and may require a Unity DevOps plan/credits depending on current account terms.
- GitHub and Unity account sign-in/authorization must be done by you; never share your passwords or access tokens in chat.
- The ZIP is Unity source code, not an APK. A cloud build must complete before an installable APK exists.
- If the build fails, copy the first meaningful error from the Unity build log here and I can help fix the project.
