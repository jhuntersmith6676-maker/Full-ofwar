using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class FrontlineCommandV2 : MonoBehaviour
{
    const int W=10,H=10;
    enum Team { Blue, Red }
    enum Ground { Plains, Forest, Hill, Town, Road, Base, Airfield }
    class Tile { public int x,y; public Ground ground; public GameObject obj; public Unit unit; public int owner; public GameObject objectiveMarker; }
    class Unit {
        public string name,kind; public Team team; public Tile tile; public GameObject obj;
        public int hp,maxHp,move,range,damage,fuel,ammo; public bool moved,attacked;
    }

    Tile[,] map=new Tile[W,H];
    List<Unit> units=new List<Unit>();
    Camera cam; Material[] mats; Unit selected; int turn=1, mission=0;
    string message="Tap a BLUE unit to select it. Capture the objectives.";
    string phase="PLAYER TURN"; bool ended=false, aiBusy=false;
    int bluePoints=0, redPoints=0, reinforcementTimer=0;
    GUIStyle title, text, button, tiny;

    string[] missionNames={"First Contact","Crossroads","Airfield Assault","The River Line","Final Push"};
    string[] missionBriefs={
        "Capture the gold crossroads objective and eliminate every enemy unit.",
        "Capture both gold town objectives to secure the supply corridor.",
        "Capture the gold airfield objective to secure air support.",
        "Capture the gold forward base and destroy the enemy tank.",
        "Capture the gold enemy headquarters objective or eliminate all enemy units."
    };

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot(){ if(FindObjectOfType<FrontlineCommandV2>()==null)new GameObject("Frontline Command V2").AddComponent<FrontlineCommandV2>(); }

    void Start(){ Application.targetFrameRate=60; MakeMaterials(); SetupCamera(); BuildMap(); SetupMission(mission); SetupGUI(); }
    Material Mat(Color c){var m=new Material(Shader.Find("Standard"));m.color=c;return m;}
    void MakeMaterials(){
        mats=new Material[]{
            Mat(new Color(.43f,.54f,.34f)),Mat(new Color(.18f,.34f,.20f)),Mat(new Color(.55f,.47f,.32f)),
            Mat(new Color(.50f,.49f,.46f)),Mat(new Color(.38f,.38f,.31f)),Mat(new Color(.45f,.40f,.28f)),
            Mat(new Color(.27f,.39f,.47f)),Mat(new Color(.10f,.40f,.88f)),Mat(new Color(.82f,.18f,.14f)),
            Mat(new Color(.97f,.77f,.18f)),Mat(new Color(.24f,.78f,.92f)),Mat(new Color(.95f,.40f,.18f))
        };
    }
    void SetupCamera(){
        cam=Camera.main;if(!cam){var c=new GameObject("Main Camera");cam=c.AddComponent<Camera>();c.tag="MainCamera";}
        cam.orthographic=true;cam.orthographicSize=8.8f;cam.transform.position=new Vector3(6.8f,16f,-8.8f);cam.transform.rotation=Quaternion.Euler(58,0,0);
        cam.clearFlags=CameraClearFlags.SolidColor;cam.backgroundColor=new Color(.06f,.08f,.10f);
        var l=new GameObject("Sun").AddComponent<Light>();l.type=LightType.Directional;l.intensity=1.15f;l.transform.rotation=Quaternion.Euler(48,-30,0);
    }
    Vector3 Pos(int x,int y)=>new Vector3(x*1.5f,0,y*1.732f+(x%2)*.866f);
    Mesh Hex(){
        var m=new Mesh();var v=new Vector3[7];v[0]=Vector3.zero;
        for(int i=0;i<6;i++){float a=Mathf.Deg2Rad*(60*i+30);v[i+1]=new Vector3(Mathf.Cos(a)*.92f,0,Mathf.Sin(a)*.92f);}
        var t=new int[18];for(int i=0;i<6;i++){t[i*3]=0;t[i*3+1]=i+1;t[i*3+2]=(i+1)%6+1;}
        m.vertices=v;m.triangles=t;m.RecalculateNormals();return m;
    }
    void BuildMap(){
        Mesh mesh=Hex();
        for(int x=0;x<W;x++)for(int y=0;y<H;y++){
            Ground g=GroundAt(x,y);var tile=new Tile{x=x,y=y,ground=g,owner=0};
            var o=new GameObject("Hex "+x+","+y);o.transform.position=Pos(x,y);
            var mf=o.AddComponent<MeshFilter>();mf.sharedMesh=mesh;var mr=o.AddComponent<MeshRenderer>();mr.material=mats[(int)g];
            var mc=o.AddComponent<MeshCollider>();mc.sharedMesh=mesh;tile.obj=o;map[x,y]=tile;
            if(g==Ground.Forest)Prop(o.transform,PrimitiveType.Capsule,new Vector3(0,.3f,0),new Vector3(.2f,.6f,.2f),new Color(.08f,.23f,.12f));
            if(g==Ground.Town||g==Ground.Base||g==Ground.Airfield)Prop(o.transform,PrimitiveType.Cube,new Vector3(0,.18f,0),new Vector3(.42f,.36f,.42f),g==Ground.Base?new Color(.25f,.35f,.42f):g==Ground.Airfield?new Color(.48f,.48f,.50f):new Color(.62f,.57f,.45f));
        }
    }
    Ground GroundAt(int x,int y){
        if(x==4&&y>=2&&y<=8)return Ground.Road;
        if(x==1&&y==8)return Ground.Base;
        if(x==8&&y==1)return Ground.Airfield;
        if((x*7+y*11)%17==0)return Ground.Forest;
        if((x*3+y*5)%19==0)return Ground.Hill;
        if((x*9+y*4)%13==0)return Ground.Town;
        return Ground.Plains;
    }
    void Prop(Transform p,PrimitiveType type,Vector3 pos,Vector3 scale,Color color){
        var o=GameObject.CreatePrimitive(type);o.transform.SetParent(p,false);o.transform.localPosition=pos;o.transform.localScale=scale;o.GetComponent<Renderer>().material=Mat(color);Destroy(o.GetComponent<Collider>());
    }
    void ClearUnits(){foreach(var u in units)if(u.obj)Destroy(u.obj);units.Clear();foreach(var t in map)if(t!=null)t.unit=null;}
    void SetupMission(int index){
        ClearUnits();
        mission=Mathf.Clamp(index,0,missionNames.Length-1);
        turn=1;ended=false;selected=null;bluePoints=0;redPoints=0;reinforcementTimer=0;
        ResetObjectives();
        Add("Rifle Squad","INF",Team.Blue,1,1,7,2,1,2,5,5);
        Add("M1 Abrams","TANK",Team.Blue,2,2,12,3,1,4,6,4);
        Add("Bradley IFV","IFV",Team.Blue,1,3,9,3,1,3,6,5);
        Add("M777 Artillery","ART",Team.Blue,0,4,6,1,3,4,4,5);
        Add("Rifle Squad","INF",Team.Red,8,8,7,2,1,2,5,5);
        Add("T-90 Tank","TANK",Team.Red,7,7,12,3,1,4,6,4);
        Add("BMP IFV","IFV",Team.Red,8,6,9,3,1,3,6,5);
        Add("Enemy Artillery","ART",Team.Red,9,5,6,1,3,4,4,5);
        if(mission==0) SetObjective(5,5,Ground.Town);
        if(mission==1){SetObjective(3,5,Ground.Town);SetObjective(6,4,Ground.Town);}
        if(mission==2) SetObjective(8,1,Ground.Airfield);
        if(mission==3) SetObjective(1,8,Ground.Base);
        if(mission==4) SetObjective(9,9,Ground.Base);
        message="MISSION "+(mission+1)+": "+missionNames[mission]+". "+missionBriefs[mission];
        phase="PLAYER TURN";
    }
    void ResetObjectives(){
        objectiveCells.Clear();
        for(int x=0;x<W;x++)for(int y=0;y<H;y++){
            Tile t=map[x,y];t.owner=0;
            if(t.objectiveMarker!=null)Destroy(t.objectiveMarker);
            t.objectiveMarker=null;
            t.ground=GroundAt(x,y);
            t.obj.GetComponent<Renderer>().material=mats[(int)t.ground];
        }
    }
    void SetObjective(int x,int y,Ground ground){
        Tile t=map[x,y];t.ground=ground;t.owner=0;
        t.obj.GetComponent<Renderer>().material=mats[(int)ground];
        objectiveCells.Add(new Vector2Int(x,y));
        var marker=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        marker.name="Capture Objective";marker.transform.position=Pos(x,y)+new Vector3(0,.055f,0);
        marker.transform.localScale=new Vector3(.78f,.07f,.78f);
        marker.GetComponent<Renderer>().material=mats[9];
        Destroy(marker.GetComponent<Collider>());t.objectiveMarker=marker;
    }
    void Add(string name,string kind,Team team,int x,int y,int hp,int move,int range,int dmg,int fuel,int ammo){
        var t=map[x,y];var u=new Unit{name=name,kind=kind,team=team,tile=t,hp=hp,maxHp=hp,move=move,range=range,damage=dmg,fuel=fuel,ammo=ammo};
        PrimitiveType shape=kind=="TANK"?PrimitiveType.Cube:kind=="ART"?PrimitiveType.Cylinder:PrimitiveType.Capsule;
        var o=GameObject.CreatePrimitive(shape);o.name=name;o.transform.position=Pos(x,y)+new Vector3(0,.42f,0);
        o.transform.localScale=kind=="TANK"?new Vector3(.9f,.45f,.7f):kind=="ART"?new Vector3(.65f,.4f,.65f):new Vector3(.48f,.72f,.48f);
        o.GetComponent<Renderer>().material=mats[team==Team.Blue?7:8];u.obj=o;t.unit=u;units.Add(u);
        var tag=new GameObject("Unit label");tag.transform.SetParent(o.transform,false);tag.transform.localPosition=new Vector3(0,1.15f,0);
        var tm=tag.AddComponent<TextMesh>();tm.text=kind;tm.fontSize=42;tm.characterSize=.065f;tm.anchor=TextAnchor.MiddleCenter;tm.color=Color.white;
    }
    int Dist(Vector2Int a,Vector2Int b){
        int aq=a.x-(a.y-(a.y&1))/2,ar=a.y,bq=b.x-(b.y-(b.y&1))/2,br=b.y;
        int ax=aq,az=ar,ay=-ax-az,bx=bq,bz=br,by=-bx-bz;
        return (Mathf.Abs(ax-bx)+Mathf.Abs(ay-by)+Mathf.Abs(az-bz))/2;
    }
    List<Vector2Int> Neighbors(Vector2Int p){
        int q=p.x-(p.y-(p.y&1))/2,r=p.y;int[,] d={{1,0},{1,-1},{0,-1},{-1,0},{-1,1},{0,1}};
        var a=new List<Vector2Int>();for(int i=0;i<6;i++){int nq=q+d[i,0],nr=r+d[i,1],col=nq+(nr-(nr&1))/2;if(col>=0&&col<W&&nr>=0&&nr<H)a.Add(new Vector2Int(col,nr));}return a;
    }
    void Update(){
        if(ended)return;
        if(Input.touchCount==2){Touch a=Input.GetTouch(0),b=Input.GetTouch(1);float d=Vector2.Distance(a.position,b.position);if(a.phase==TouchPhase.Began||b.phase==TouchPhase.Began)pinch=d;else if(pinch>0){cam.orthographicSize=Mathf.Clamp(cam.orthographicSize+(pinch-d)*.012f,5,13);pinch=d;}return;}
        bool down=Input.GetMouseButtonDown(0)||(Input.touchCount==1&&Input.GetTouch(0).phase==TouchPhase.Began);if(!down||phase!="PLAYER TURN")return;
        Vector2 s=Input.touchCount>0?Input.GetTouch(0).position:(Vector2)Input.mousePosition;Ray ray=cam.ScreenPointToRay(s);
        if(!Physics.Raycast(ray,out RaycastHit hit,100))return;
        Unit u=units.Find(v=>v.obj==hit.collider.gameObject&&v.hp>0);
        if(u!=null){if(u.team==Team.Blue){selected=u;message=Info(u);}else if(selected!=null)Attack(selected,u);return;}
        Tile tile=Closest(hit.point);if(tile!=null)MoveTo(tile);
    }
    float pinch;
    Tile Closest(Vector3 p){Tile best=null;float bd=999;foreach(var t in map){Vector3 v=Pos(t.x,t.y);float d=Vector2.Distance(new Vector2(p.x,p.z),new Vector2(v.x,v.z));if(d<bd){bd=d;best=t;}}return bd<1.2f?best:null;}
    string Info(Unit u)=>u.name+"  HP "+u.hp+"/"+u.maxHp+"  Fuel "+u.fuel+"  Ammo "+u.ammo;
    void MoveTo(Tile t){
        if(selected==null)return;if(t.unit!=null){message="Occupied hex.";return;}
        int d=Dist(new Vector2Int(selected.tile.x,selected.tile.y),new Vector2Int(t.x,t.y));
        if(selected.moved||selected.fuel<=0||d>selected.move){message="Cannot move: already moved, out of fuel, or too far.";return;}
        selected.tile.unit=null;selected.tile=t;t.unit=selected;selected.moved=true;selected.fuel--;selected.obj.transform.position=Pos(t.x,t.y)+new Vector3(0,.42f,0);
        if(objectiveCells.Contains(new Vector2Int(t.x,t.y))){
            t.owner=1;bluePoints++;
            if(t.objectiveMarker!=null)t.objectiveMarker.GetComponent<Renderer>().material=mats[7];
            message="OBJECTIVE CAPTURED! Friendly forces now control this position.";
        } else message=selected.name+" moved.";
        selected=null;CheckMission();
    }
    void Attack(Unit a,Unit b){
        int d=Dist(new Vector2Int(a.tile.x,a.tile.y),new Vector2Int(b.tile.x,b.tile.y));
        if(a.attacked||a.ammo<=0||d>a.range){message=a.attacked?"Already attacked this turn.":a.ammo<=0?"Out of ammunition.":"Target out of range.";return;}
        int damage=a.damage;if(b.tile.ground==Ground.Forest||b.tile.ground==Ground.Hill)damage=Mathf.Max(1,damage-1);
        b.hp-=damage;a.ammo--;a.attacked=true;message=a.name+" fired: "+damage+" damage.";
        if(b.hp<=0){b.tile.unit=null;units.Remove(b);Destroy(b.obj);message+=" Enemy eliminated.";}
        selected=null;CheckMission();
    }
    void CheckMission(){
        if(!units.Exists(u=>u.team==Team.Blue&&u.hp>0)){
            ended=true;phase="DEFEAT";message="Your force has been destroyed. Restart the mission.";return;
        }
        int captured=0;
        foreach(Vector2Int p in objectiveCells)if(map[p.x,p.y].owner==1)captured++;
        bool noEnemies=!units.Exists(u=>u.team==Team.Red&&u.hp>0);
        bool complete=false;
        switch(mission){
            case 0: complete=captured>=1&&noEnemies; break;
            case 1: complete=captured>=2; break;
            case 2: complete=captured>=1; break;
            case 3: complete=captured>=1&&!units.Exists(u=>u.team==Team.Red&&u.kind=="TANK"&&u.hp>0); break;
            case 4: complete=captured>=1||noEnemies; break;
        }
        if(complete)Win();
    }
    void Win(){
        ended=true;phase="MISSION COMPLETE";
        message="Victory! "+missionNames[mission]+" completed. "+(mission<4?"Choose NEXT MISSION to continue the campaign.":"Campaign completed!");
    }
    void EndTurn(){
        if(phase!="PLAYER TURN"||ended)return;selected=null;phase="ENEMY TURN";message="Enemy forces are taking their turn.";
        foreach(var e in new List<Unit>(units)){
            if(e.team!=Team.Red||e.hp<=0)continue;
            Unit target=null;int best=999;
            foreach(var p in units)if(p.team==Team.Blue&&p.hp>0){int d=Dist(new Vector2Int(e.tile.x,e.tile.y),new Vector2Int(p.tile.x,p.tile.y));if(d<best){best=d;target=p;}}
            if(target==null)break;
            if(best<=e.range&&e.ammo>0){target.hp-=e.damage;e.ammo--;e.attacked=true;if(target.hp<=0){target.tile.unit=null;units.Remove(target);Destroy(target.obj);}}
            else if(e.fuel>0){
                Vector2Int step=new Vector2Int(e.tile.x,e.tile.y);int bd=best;
                foreach(var n in Neighbors(step)){Tile t=map[n.x,n.y];if(t.unit==null){int d=Dist(n,new Vector2Int(target.tile.x,target.tile.y));if(d<bd){bd=d;step=n;}}}
                if(step.x!=e.tile.x||step.y!=e.tile.y){e.tile.unit=null;e.tile=map[step.x,step.y];e.tile.unit=e;e.obj.transform.position=Pos(step.x,step.y)+new Vector3(0,.42f,0);e.fuel--;}
            }
        }
        CheckMission();if(!ended){turn++;phase="PLAYER TURN";foreach(var u in units)if(u.team==Team.Blue){u.moved=false;u.attacked=false;u.fuel=Mathf.Min(6,u.fuel+1);u.ammo=Mathf.Min(5,u.ammo+1);}message="Your turn. Fuel and ammunition partially resupplied.";}
    }
    void NextMission(){if(mission<4)SetupMission(mission+1);else SetupMission(0);}
    void Restart(){SetupMission(mission);}
    void SetupGUI(){
        title=new GUIStyle(GUI.skin.label){fontSize=24,fontStyle=FontStyle.Bold,normal={textColor=Color.white}};
        text=new GUIStyle(GUI.skin.label){fontSize=15,wordWrap=true,normal={textColor=Color.white}};
        button=new GUIStyle(GUI.skin.button){fontSize=17,fontStyle=FontStyle.Bold};
        tiny=new GUIStyle(text){fontSize=12};
    }
    void OnGUI(){
        if(title==null)SetupGUI();float sc=Mathf.Clamp(Screen.width/1000f,.72f,1.4f);GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,new Vector3(sc,sc,1));
        float w=Screen.width/sc,h=Screen.height/sc;
        GUI.Box(new Rect(10,10,365,125),"");
        GUI.Label(new Rect(22,14,340,34),"FRONTLINE COMMAND",title);
        GUI.Label(new Rect(22,49,340,24),"MODERN CONFLICTS  |  "+phase,text);
        GUI.Label(new Rect(22,75,340,20),"MISSION "+(mission+1)+"/5: "+missionNames[mission],tiny);
        GUI.Label(new Rect(22,96,340,25),"TURN "+turn+"    BLUE "+Count(Team.Blue)+"  RED "+Count(Team.Red),tiny);
        GUI.Box(new Rect(10,h-142,w-20,130),"");
        GUI.Label(new Rect(22,h-133,w-255,56),message,text);
        if(selected!=null)GUI.Label(new Rect(22,h-76,w-255,30),Info(selected),tiny);
        if(!ended&&phase=="PLAYER TURN"&&GUI.Button(new Rect(w-225,h-105,205,52),"END TURN",button))EndTurn();
        if(ended){
            if(GUI.Button(new Rect(w-225,h-105,205,46),"RESTART MISSION",button))Restart();
            if(phase=="MISSION COMPLETE"&&mission<4&&GUI.Button(new Rect(w-225,h-54,205,42),"NEXT MISSION",button))NextMission();
            if(phase=="MISSION COMPLETE"&&mission==4&&GUI.Button(new Rect(w-225,h-54,205,42),"PLAY CAMPAIGN AGAIN",button))SetupMission(0);
        }
        GUI.Label(new Rect(18,145,320,125),"MISSION BRIEFING\n"+missionBriefs[mission]+"\n\nTap blue unit, then empty hex to move. Tap red unit to attack. Pinch to zoom.",tiny);
        GUI.Label(new Rect(18,h-12,500,18),"Prototype campaign • Fuel and ammo are limited • Capture marked facilities for supply",tiny);
    }
    int Count(Team t)=>units.FindAll(u=>u.team==t&&u.hp>0).Count;
}

