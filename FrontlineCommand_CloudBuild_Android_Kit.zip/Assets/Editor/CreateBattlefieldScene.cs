#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
public class FrontlineSceneSetup : EditorWindow {
 [MenuItem("Frontline Command/Setup Playable Scene")]
 public static void Setup(){
   var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
   string path="Assets/Scenes/Battlefield.unity";
   EditorSceneManager.SaveScene(scene,path);
   EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(path,true)};
   AssetDatabase.Refresh();
   EditorUtility.DisplayDialog("Frontline Command","Battlefield scene created and added to Build Settings. Press Play to launch.","OK");
 }
}
#endif
