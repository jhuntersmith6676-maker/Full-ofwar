# Frontline Command: Modern Conflicts — Campaign Prototype V2

A Unity source project for an Android-first, touch-controlled turn-based military hex strategy game.

## New in V2
- Five short campaign missions with briefings and next-mission progression
- Infantry, main battle tanks, IFVs and artillery
- Health, fuel and ammunition values
- Limited movement and ammunition; partial resupply at turn start
- Clearly marked gold mission objectives with capture tracking
- Mission-specific victory conditions for all five missions
- Capturable towns, forward base and airfield
- Terrain defense bonus for forest and hill tiles
- Basic enemy AI with movement and attacks
- Touch input and pinch-to-zoom
- Restart, victory and defeat flows

## Open and play
1. Install Unity Hub and Unity 2022.3 LTS (or a newer LTS).
2. Open this folder as a Unity project.
3. If no scene is open, use menu **Frontline Command > Setup Playable Scene**.
4. Press **Play**. The game builds the map and armies automatically.

## Build for Android
1. Install Android Build Support, Android SDK & NDK Tools, and OpenJDK from Unity Hub.
2. In Unity select **File > Build Settings** (or **Build Profiles**) > Android > Switch Platform.
3. Use **Frontline Command > Setup Playable Scene** to create and register the scene.
4. In Player Settings use package ID `com.frontlinecommand.modernconflicts`, Landscape orientation, and ARM64 for release builds.
5. Select Build to create an APK, or Build And Run with an Android device connected.

## Controls
- Tap a blue unit to select it.
- Tap an empty hex within movement range to move.
- Tap a red enemy in weapon range to attack.
- Tap END TURN to let the AI respond.
- Pinch with two fingers to zoom.
- Capture facilities and complete mission objectives.

## Honest status
This is a source project for a playable prototype, not a signed APK. It requires Unity and Android Build Support to compile. It has not been compiled or device-tested in this environment. The five missions currently share a generated battlefield and starting force; objectives/briefings vary by mission. This is a foundation for further balancing, art, sound, save/load, and more advanced pathfinding.
